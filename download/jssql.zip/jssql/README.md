jssql
=====

JS SQL Library
