(function() {
	JSDB.events = events;
	JSDB.SERVER = SERVER = new Server();
	//console.log("Server loading...");
	SERVER.load(function() {
		//console.log("Server loaded:", SERVER);
	}, function(error) {
		console.error(error);
	});
	//console.dir(SERVER);
})();
